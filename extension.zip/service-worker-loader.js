import './assets/service-worker.js-BKFVWbfP.js';
